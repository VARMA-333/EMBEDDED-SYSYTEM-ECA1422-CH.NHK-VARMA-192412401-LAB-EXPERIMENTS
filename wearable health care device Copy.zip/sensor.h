#ifndef SENSOR_H
#define SENSOR_H

// This acts as a translator between C++ (sketch.ino) and C (sensor.c)
#ifdef __cplusplus
extern "C" {
#endif

void Sensor_Init(void);
int Read_HeartRate(void);

#ifdef __cplusplus
}
#endif

#endif