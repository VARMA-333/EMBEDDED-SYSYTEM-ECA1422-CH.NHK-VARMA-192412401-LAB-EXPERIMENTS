#include <avr/io.h>
#include <avr/sleep.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "sensor.h"

void UART_Init(unsigned int baud) {
    unsigned int ubrr = 16000000 / 16 / baud - 1;
    UBRR0H = (unsigned char)(ubrr >> 8);
    UBRR0L = (unsigned char)ubrr;
    UCSR0B = (1 << RXEN0) | (1 << TXEN0);
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void UART_Transmit(unsigned char data) {
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

void UART_Print(const char* str) {
    while (*str) {
        UART_Transmit(*str++);
    }
}

void Setup_WakeUp_Interrupt(void) {
    DDRD &= ~(1 << DDD2);
    PORTD |= (1 << PORTD2); 
    EICRA &= ~((1 << ISC01) | (1 << ISC00));
    EIMSK |= (1 << INT0);
}

ISR(INT0_vect) {
}

int main(void) {
    char buffer[64];
    
    UART_Init(9600);
    Sensor_Init();
    Setup_WakeUp_Interrupt();
    
    UART_Print("System Initialized. Entering Low Power Mode...\r\n");
    _delay_ms(1000);
    
    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    sleep_enable();
    
    sei(); 
    
    while (1) {
        sleep_cpu(); 
        
        _delay_ms(50);
        
        UART_Print("Woke up! Reading vitals...\r\n");
        
        int raw_adc = Read_HeartRate();
        
        int bpm = 60 + (raw_adc * 80 / 1023);
        
        sprintf(buffer, "Simulated Heart Rate: %d BPM\r\n", bpm);
        UART_Print(buffer);
        
        UART_Print("Going back to sleep to save power...\r\n\n");
        
        _delay_ms(1000);
    }
    return 0;
}