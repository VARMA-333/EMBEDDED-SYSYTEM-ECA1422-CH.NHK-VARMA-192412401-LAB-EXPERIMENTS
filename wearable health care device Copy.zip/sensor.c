#include <avr/io.h>
#include "sensor.h"

void Sensor_Init(void) {
    // Set AVCC with external capacitor at AREF pin
    ADMUX = (1 << REFS0);
    // Enable ADC and set prescaler to 128 (16MHz/128 = 125kHz)
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

int Read_HeartRate(void) {
    // Start the ADC conversion on channel 0 (Pin A0)
    ADCSRA |= (1 << ADSC);
    
    // Wait for the conversion to complete
    while (ADCSRA & (1 << ADSC));
    
    // Return the 10-bit ADC result (0 - 1023)
    return ADC;
}